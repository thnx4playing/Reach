import { useEffect, useMemo, useRef, useState } from 'react';

type AnimatorOpts = {
  fps?: number;
  loop?: boolean;       // default true
  holdOnEnd?: boolean;  // if !loop, hold last frame
  onEnd?: () => void;   // optional callback when a non-looping anim finishes
};

export function useAnimator(frames: string[], opts: AnimatorOpts = {}) {
  const { fps = 12, loop = true, holdOnEnd = true, onEnd } = opts;
  const [index, setIndex] = useState(0);

  // Reset to frame 0 whenever we truly switch strips
  const frameKey = useMemo(() => frames.join('|'), [frames]);
  useEffect(() => setIndex(0), [frameKey]);

  // Drive the frame index
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  useEffect(() => {
    // stop any prior timer
    if (timerRef.current) clearInterval(timerRef.current);
    if (frames.length <= 1 || fps <= 0) return;

    timerRef.current = setInterval(() => {
      setIndex((i) => {
        const next = i + 1;
        if (next < frames.length) return next;

        // reached the end
        if (loop) return 0;

        // stop advancing
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }
        onEnd?.();
        return holdOnEnd ? frames.length - 1 : i; // stick on last frame by default
      });
    }, 1000 / fps);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = null;
    };
  }, [frameKey, fps, loop, holdOnEnd, onEnd, frames.length]);

  return frames[index] ?? frames[0];
}
