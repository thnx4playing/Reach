import React from "react";
import { Group, Image as SkImage } from "@shopify/react-native-skia";
import { MAPS, MapName } from "../content/maps";
import { useMapSkImage } from "./MapImageContext";

export function PrefabNode({
  map,
  name,
  x = 0,
  y = 0,
  scale = 1,
}: { map: MapName; name: string; x?: number; y?: number; scale?: number }) {
  const { grid, prefabs } = MAPS[map];
  const skImage = useMapSkImage();
  const pf = prefabs.prefabs[name];
  if (!pf || !skImage) return null;

  const tile = prefabs.meta.tileSize;

  return (
    <Group transform={[{ translateX: x }, { translateY: y }]}>
      {/* draw via named cells */}
      {pf.cells?.map((row, ry) =>
        row.map((cell, rx) => {
          if (!cell) return null;
          const f = (grid as any)[cell] || (grid as any)?.frames?.[cell];
          if (!f) return null;
          const dx = rx * tile * scale;
          const dy = ry * tile * scale;

          return (
            <SkImage
              key={`c-${rx}-${ry}`}
              image={skImage}
              x={dx}
              y={dy}
              width={f.w * scale}
              height={f.h * scale}
              // ✅ MUST be an object with width/height keys
              rect={{ x: f.x, y: f.y, width: f.w, height: f.h }}
              // optional: keep pixel art crisp
              // filterMode="nearest"
            />
          );
        })
      )}

      {/* draw via explicit rects */}
      {pf.rects?.map((row, ry) =>
        row.map((r, rx) => {
          if (!r) return null;
          const dx = rx * tile * scale;
          const dy = ry * tile * scale;

          return (
            <SkImage
              key={`r-${rx}-${ry}`}
              image={skImage}
              x={dx}
              y={dy}
              width={r.w * scale}
              height={r.h * scale}
              rect={{ x: r.x, y: r.y, width: r.w, height: r.h }}
            />
          );
        })
      )}
    </Group>
  );
}