import React, { createContext, useContext } from "react";
import { useImage, SkImage as SkiaImage } from "@shopify/react-native-skia";

type Ctx = { skImage: SkiaImage | null };
const MapImageCtx = createContext<Ctx>({ skImage: null });

export function useMapSkImage() {
  return useContext(MapImageCtx).skImage;
}

/**
 * Wrap per-map rendering with this. Pass the *numeric* require() or a URI.
 */
export function MapImageProvider({
  source,
  children,
}: { source: number | string; children: React.ReactNode }) {
  // IMPORTANT: let Skia load the numeric asset directly.
  const skImage = useImage(source as any);
  return <MapImageCtx.Provider value={{ skImage }}>{children}</MapImageCtx.Provider>;
}
