import { Dimensions } from 'react-native';
import type { MapName } from './maps';
import { makeFloorRow, prefabWidthPx, getTileSize } from './maps';

// Re-export MapName for convenience
export type { MapName } from './maps';

const { width, height } = Dimensions.get('window');

export interface Platform {
  prefab: string;
  x: number;
  y: number;
  scale?: number;
}

export interface LevelData {
  mapName: MapName;
  platforms: Platform[];
  characterSpawn: {
    x: number;
    y: number;
  };
}


// Debug helper function calculations
console.log('📐 Level Generation Debug:', {
  screenDimensions: { width, height },
  darkTileSize: getTileSize('dark'),
  floorRowSample: makeFloorRow('dark', width, height - 64, 2).slice(0, 3), // First 3 floor tiles
  rightPlatformWidth: prefabWidthPx('dark', 'right-platform', 2),
  leftPlatformWidth: prefabWidthPx('dark', 'left-platform', 2),
  floorY: height - getTileSize('dark') * 2 * 2,
  leftPlatformY: height / 2 - 64,
  rightPlatformY: height / 3,
  rightPlatformX: width - prefabWidthPx('dark', 'right-platform', 2)
});

// Enhanced level layouts for each map theme with better positioning
export const LEVELS: Record<MapName, LevelData> = {
  dark: {
    mapName: 'dark',
    platforms: [
      // Auto-generated solid floor across entire bottom (2 tiles tall)
      ...makeFloorRow('dark', width, height - getTileSize('dark') * 2 * 2, 2),
      
      // Left platform - middle of screen, flush to left
      { prefab: 'left-platform', x: 0, y: height / 2 - 64, scale: 2 },
      
      // Right platform - 1/3 up screen, flush to right (properly positioned)
      { 
        prefab: 'right-platform', 
        x: width - prefabWidthPx('dark', 'right-platform', 2), 
        y: height / 3, 
        scale: 2 
      },
      
      // Decorative elements
      { prefab: 'lit-torch', x: 100, y: height - 100, scale: 2 },
      { prefab: 'lit-torch', x: width - 100, y: height - 100, scale: 2 },
    ],
    characterSpawn: {
      x: width / 2,
      y: height - 100, // On top of floor
    },
  },
  
  desert: {
    mapName: 'desert',
    platforms: [
      // Auto-generated solid floor across entire bottom
      ...makeFloorRow('desert', width, height - getTileSize('desert') * 2 * 2, 2),
      
      // Left platform - middle of screen, flush to left
      { prefab: 'left-platform', x: 0, y: height / 2 - 64, scale: 2 },
      
      // Right platform - 1/3 up screen, flush to right (properly positioned)
      { 
        prefab: 'right-platform', 
        x: width - prefabWidthPx('desert', 'right-platform', 2), 
        y: height / 3, 
        scale: 2 
      },
      
      // Desert decorations
      { prefab: 'vase', x: 200, y: height - 100, scale: 2 },
      { prefab: 'broke-vase', x: 300, y: height - 100, scale: 2 },
    ],
    characterSpawn: {
      x: width / 2,
      y: height - 100, // On top of floor
    },
  },
  
  dungeon: {
    mapName: 'dungeon',
    platforms: [
      // Auto-generated solid floor across entire bottom
      ...makeFloorRow('dungeon', width, height - getTileSize('dungeon') * 2 * 2, 2),
      
      // Left platform - middle of screen, flush to left
      { prefab: 'left-platform', x: 0, y: height / 2 - 64, scale: 2 },
      
      // Right platform - 1/3 up screen, flush to right (properly positioned)
      { 
        prefab: 'right-platform', 
        x: width - prefabWidthPx('dungeon', 'right-platform', 2), 
        y: height / 3, 
        scale: 2 
      },
      

      
      // Dungeon lighting and decorations
      { prefab: 'lit-torch', x: 50, y: height - 100, scale: 2 },
      { prefab: 'lit-torch', x: width - 50, y: height - 100, scale: 2 },
      { prefab: 'overhead-light', x: width / 2 - 16, y: height - 250, scale: 2 },
      { prefab: 'vase-tall', x: 150, y: height - 100, scale: 2 },
    ],
    characterSpawn: {
      x: width / 2,
      y: height - 100, // On top of floor
    },
  },
  
  frozen: {
    mapName: 'frozen',
    platforms: [
      // Auto-generated solid floor across entire bottom
      ...makeFloorRow('frozen', width, height - getTileSize('frozen') * 2 * 2, 2),
      
      // Left platform - middle of screen, flush to left
      { prefab: 'left-platform', x: 0, y: height / 2 - 64, scale: 2 },
      
      // Right platform - 1/3 up screen, flush to right (properly positioned)
      { 
        prefab: 'right-platform', 
        x: width - prefabWidthPx('frozen', 'right-platform', 2), 
        y: height / 3, 
        scale: 2 
      },
      

      
      // Frozen decorations
      { prefab: 'vase', x: 200, y: height - 100, scale: 2 },
      { prefab: 'broke-vase-tall', x: 350, y: height - 100, scale: 2 },
    ],
    characterSpawn: {
      x: width / 2,
      y: height - 100, // On top of floor
    },
  },
  
  grassy: {
    mapName: 'grassy',
    platforms: [
      // Auto-generated solid floor across entire bottom
      ...makeFloorRow('grassy', width, height - getTileSize('grassy') * 2 * 2, 2),
      
      // Left platform - middle of screen, flush to left
      { prefab: 'left-platform', x: 0, y: height / 2 - 64, scale: 2 },
      
      // Right platform - 1/3 up screen, flush to right (properly positioned)
      { 
        prefab: 'right-platform', 
        x: width - prefabWidthPx('grassy', 'right-platform', 2), 
        y: height / 3, 
        scale: 2 
      },
      

      
      // Natural decorations
      { prefab: 'vase-tall', x: 80, y: height - 100, scale: 2 },
      { prefab: 'vase', x: 300, y: height - 100, scale: 2 },
      { prefab: 'broke-vase', x: 400, y: height - 100, scale: 2 },
    ],
    characterSpawn: {
      x: width / 2,
      y: height - 100, // On top of floor
    },
  },
};
