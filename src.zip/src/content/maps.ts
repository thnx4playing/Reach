import type { SkRect } from "@shopify/react-native-skia";

// ---- Types ----
export type CellName = `cell-${number}-${number}`;
export type CellsRow = Array<CellName | null>;
export type RectRow  = Array<({ x:number; y:number; w:number; h:number } | null)>;

export type Prefab = {
  cells: CellsRow[];  // use these with atlas.frames[frameName]
  rects: RectRow[];   // or draw via srcRect directly
};

export type PrefabCatalog = {
  meta: {
    map: string;
    tileset_image: string;
    tileset_grid_json: string;
    tileSize: number;
  };
  prefabs: Record<string, Prefab>;
};

// ---- Imports per map (static so Metro bundles them) ----
// DARK
import darkGrid   from "../../assets/maps/dark/dark-tileset_grid.json";
import darkPrefs  from "../../assets/maps/dark/dark_prefabs.json";
const darkImage   = require("../../assets/maps/dark/dark-tileset.png") as number;

// DESERT
import desertGrid  from "../../assets/maps/desert/desert-tileset_grid.json";
import desertPrefs from "../../assets/maps/desert/desert_prefabs.json";
const desertImage  = require("../../assets/maps/desert/desert-tileset.png") as number;

// DUNGEON
import dungeonGrid  from "../../assets/maps/dungeon/dungeon-tileset_grid.json";
import dungeonPrefs from "../../assets/maps/dungeon/dungeon_prefabs.json";
const dungeonImage  = require("../../assets/maps/dungeon/dungeon-tileset.png") as number;

// FROZEN
import frozenGrid  from "../../assets/maps/frozen/frozen-tileset_grid.json";
import frozenPrefs from "../../assets/maps/frozen/frozen_prefabs.json";
const frozenImage  = require("../../assets/maps/frozen/frozen-tileset.png") as number;

// GRASSY
import grassyGrid  from "../../assets/maps/grassy/grassy-tileset_grid.json";
import grassyPrefs from "../../assets/maps/grassy/grassy_prefabs.json";
const grassyImage  = require("../../assets/maps/grassy/grassy-tileset.png") as number;

// ---- Registry ----
export const MAPS = {
  dark:    { image: darkImage,    grid: darkGrid,    prefabs: darkPrefs  as PrefabCatalog },
  desert:  { image: desertImage,  grid: desertGrid,  prefabs: desertPrefs as PrefabCatalog },
  dungeon: { image: dungeonImage, grid: dungeonGrid, prefabs: dungeonPrefs as PrefabCatalog },
  frozen:  { image: frozenImage,  grid: frozenGrid,  prefabs: frozenPrefs as PrefabCatalog },
  grassy:  { image: grassyImage,  grid: grassyGrid,  prefabs: grassyPrefs as PrefabCatalog },
} as const;

export type MapName = keyof typeof MAPS;

// Utility
export function getPrefab(map: MapName, name: string): Prefab | undefined {
  return MAPS[map].prefabs.prefabs[name];
}
export function getTileSize(map: MapName) {
  return MAPS[map].prefabs.meta.tileSize;
}

// Helper functions for level generation
export function makeFloorRow(mapName: MapName, screenWidth: number, y: number, scale = 2) {
  const tile = getTileSize(mapName) * scale;         // 16 * 2 = 32
  const count = Math.ceil(screenWidth / tile) + 1;   // fill + 1 for safety
  
  console.log('🏗️ makeFloorRow Debug:', {
    mapName,
    screenWidth,
    y,
    scale,
    tile,
    count,
    totalTiles: count * 2
  });
  
  // Create 2 rows of floor tiles to make a solid floor
  const floorTiles = [];
  for (let row = 0; row < 2; row++) {
    for (let i = 0; i < count; i++) {
      const tileData = {
        prefab: 'floor' as const,
        x: i * tile,
        y: y + (row * tile), // Second row is one tile lower
        scale,
      };
      floorTiles.push(tileData);
      
      // Log first few tiles for debugging
      if (i < 3 && row < 2) {
        console.log(`🧱 Floor Tile [${row}][${i}]:`, tileData);
      }
    }
  }
  
  console.log('🏗️ makeFloorRow Result:', {
    totalTiles: floorTiles.length,
    firstTile: floorTiles[0],
    lastTile: floorTiles[floorTiles.length - 1]
  });
  
  // Optional: Log the level builder's floor row once (only in dev)
  if (__DEV__) {
    console.log("[Level:floorRow]", {
      map: mapName,
      y: y,
      scale: scale,
      tileSize: getTileSize(mapName),
      count: floorTiles.length,
      firstThree: floorTiles.slice(0, 3),
    });
  }
  
  return floorTiles;
}

export function prefabWidthPx(mapName: MapName, prefabName: string, scale = 2) {
  const tile = getTileSize(mapName) * scale;
  const pf = getPrefab(mapName, prefabName)!;
  
  console.log('📏 prefabWidthPx Debug:', {
    mapName,
    prefabName,
    scale,
    tile,
    hasCells: !!pf.cells,
    hasRects: !!pf.rects,
    cellsRows: pf.cells?.length,
    rectsRows: pf.rects?.length
  });
  
  // For cells, count the actual width (excluding nulls at the end)
  const colsFromCells = pf.cells?.reduce((maxCols, row, rowIndex) => {
    // Find the last non-null cell in this row
    let lastCol = -1;
    for (let i = row.length - 1; i >= 0; i--) {
      if (row[i] !== null) {
        lastCol = i;
        break;
      }
    }
    const rowWidth = lastCol + 1;
    console.log(`📏 Cells Row ${rowIndex}:`, { row, lastCol, rowWidth });
    return Math.max(maxCols, rowWidth);
  }, 0) ?? 0;
  
  // For rects, count the actual width (excluding nulls at the end)
  const colsFromRects = pf.rects?.reduce((maxCols, row, rowIndex) => {
    // Find the last non-null rect in this row
    let lastCol = -1;
    for (let i = row.length - 1; i >= 0; i--) {
      if (row[i] !== null) {
        lastCol = i;
        break;
      }
    }
    const rowWidth = lastCol + 1;
    console.log(`📏 Rects Row ${rowIndex}:`, { row, lastCol, rowWidth });
    return Math.max(maxCols, rowWidth);
  }, 0) ?? 0;
  
  const cols = Math.max(colsFromCells, colsFromRects, 1);
  const widthPx = cols * tile;
  
  console.log('📏 prefabWidthPx Result:', {
    mapName,
    prefabName,
    colsFromCells,
    colsFromRects,
    finalCols: cols,
    widthPx
  });
  
  return widthPx;
}