import React from "react";
import { Canvas, Atlas, Group, useImage, rect as skRect, Skia } from "@shopify/react-native-skia";

type Frame = { x: number; y: number; w: number; h: number };

export interface SubImageProps {
  uri: any;                 // require(...) or string
  frame: Frame;             // source frame rect inside the atlas
  x: number;                // destination top-left on the Canvas
  y: number;                // destination top-left on the Canvas
  scale?: number;           // default 1
  debug?: boolean;          // optional white box to verify positioning
}

export default function SubImage({
  uri,
  frame,
  x,
  y,
  scale = 1,
  debug = false,
}: SubImageProps) {
  const img = useImage(uri);
  
  console.log("[SUBIMAGE DEBUG] uri=", uri, "img=", img ? `loaded ${img.width}x${img.height}` : "loading...", "frame=", frame, "x=", x, "y=", y, "scale=", scale);
  
  const dw = frame.w * scale;
  const dh = frame.h * scale;

  // Use Atlas component like the character sprite does
  return (
    <Canvas style={{ position: "absolute", left: x, top: y, width: dw, height: dh, backgroundColor: "red" }}>
      {img && (
        <Group transform={[{ scaleX: scale }, { scaleY: scale }]}>
          <Atlas
            image={img}
            sprites={[skRect(frame.x, frame.y, frame.w, frame.h)]}
            transforms={[Skia.RSXform(1, 0, 0, 0)]}
          />
        </Group>
      )}
    </Canvas>
  );
}