import React, { useMemo } from "react";
import { useHealth } from "../systems/health/HealthContext";
import hpJson from "../../assets/ui/hp_bar.json";
import hpPng from "../../assets/ui/hp_bar.png";
import SubImage from "./SubImage";

type Frame = { x: number; y: number; w: number; h: number };
type Atlas = {
  frames: Record<string, Frame>;
};

const ATLAS = hpJson as unknown as Atlas;

/** Map barsRemaining (5..0) to a frame key in the JSON */
function getFrameFor(barsRemaining: number): Frame {
  const key = `hp_${Math.max(0, Math.min(5, barsRemaining))}`;
  const f = ATLAS.frames[key];
  if (!f) {
    // fallback to full health frame if something odd happens
    return ATLAS.frames["hp_5"] || { x: 0, y: 0, w: 116, h: 23 };
  }
  return f;
}

type Props = {
  hits: number;
  maxHits: number;
};

export default function HPBar({ hits, maxHits }: Props) {
  const bars = maxHits - hits; // bars remaining
  const frame = useMemo(() => getFrameFor(bars), [bars]);

  // Top-right placement for the bar (tweak to taste)
  const x = 12;
  const y = 12;
  const scale = 2; // 2x the frame size

  console.log("[HPBAR] bars=", bars, "hits=", hits, "frame=", frame);

  // Always render one single frame
  return (
    <SubImage
      uri={hpPng}
      frame={frame}
      x={x}
      y={y}
      scale={scale}
      debug={false} // set to true to see the clip box
    />
  );
}