// src/config/mapProfiles.ts
import type { MapName } from "../types";

// Two families: Core maps (grassy, frozen, etc) and Boss rooms
export type MapProfileId = "core" | "boss";

export interface MapProfile {
  id: MapProfileId;
  floorPrefab: "floor-final" | "floor"; // which prefab to use to compute floorTopY
  spawnZ: number;                       // vertical offset at spawn; 0 = stand on floor
  groundedClampFrames: number;          // how many frames to hard-clamp to ground after entry
  doorIce?: {                           // optional boss-room door-ice render constants
    scale: number;                      // DoorIceSprite scale
    nudgeX: number;                     // center nudge in px (left = negative)
    offsetYAboveTop: number;            // additional px above the platform top
  };
}

// Map → profile
export const MAP_PROFILE_BY_MAP: Record<MapName, MapProfileId> = {
  grassy: "core",
  frozen: "core",
  desert: "core",
  dungeon: "core",
  dark: "core",
  bossroom: "boss",
} as const;

// Actual profiles
export const MAP_PROFILES: Record<MapProfileId, MapProfile> = {
  core: {
    id: "core",
    floorPrefab: "floor-final",
    spawnZ: 0,
    groundedClampFrames: 2,
  },
  boss: {
    id: "boss",
    floorPrefab: "floor-final",
    spawnZ: 0,
    groundedClampFrames: 2,
    doorIce: { scale: 1.5, nudgeX: -15, offsetYAboveTop: 32 },
  },
};

export function getMapProfile(mapName: MapName): MapProfile {
  const pid = MAP_PROFILE_BY_MAP[mapName] ?? "core";
  return MAP_PROFILES[pid];
}
